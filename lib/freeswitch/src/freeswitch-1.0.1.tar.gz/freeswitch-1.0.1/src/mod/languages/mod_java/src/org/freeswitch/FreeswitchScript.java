package org.freeswitch;

public interface FreeswitchScript
{
    void run(String uuid, String args);
}

